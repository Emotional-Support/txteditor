from txteditor.txt import Txt
