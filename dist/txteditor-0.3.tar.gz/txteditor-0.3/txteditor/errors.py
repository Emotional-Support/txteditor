class InvalidFilePathError(BaseException):
    pass


class InvalidFileTypeError(BaseException):
    pass
