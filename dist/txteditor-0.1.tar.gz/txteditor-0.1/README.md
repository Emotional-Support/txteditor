Txt Editor Thingy
